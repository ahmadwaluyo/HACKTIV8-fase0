function shoutOut(){
return 'Halo function!';
}

console.log(shoutOut());
