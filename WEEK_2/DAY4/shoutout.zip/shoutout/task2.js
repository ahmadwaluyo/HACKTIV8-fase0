function calculateMultiply(num1,num2){
  return num1*num2;
}

console.log(calculateMultiply(5,6));
