 function processSentence(name,age,address,hobby){
   console.log(`Nama saya ${name}, umur saya ${age} tahun, alamat saya di ${address}, dan saya punya hobby yaitu ${hobby}!`);
 }

 processSentence('Agus','30','Jl.Malioboro, Yogjakarta','gaming');
