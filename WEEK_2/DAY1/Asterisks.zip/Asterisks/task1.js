let rows1 = 5;

for (var i = 0; i < rows1; i++) {
  let rows1 = '*';
  console.log(rows1);
}
