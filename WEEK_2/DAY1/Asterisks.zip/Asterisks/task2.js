let rows2 = 6;
let h = '';

for (i = 0; i < rows2; i++) {
  h = '';
    for (j = 0; j < rows2; j++) {
    h += '*';
    }
    console.log(h);
  }
