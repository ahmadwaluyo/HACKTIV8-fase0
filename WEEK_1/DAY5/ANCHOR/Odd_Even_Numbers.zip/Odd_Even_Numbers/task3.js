for (var i = 100; i <= 200; i+=7) {
  if (i%8===0) {
    console.log(i);
  }else {
    null;
  }
}
