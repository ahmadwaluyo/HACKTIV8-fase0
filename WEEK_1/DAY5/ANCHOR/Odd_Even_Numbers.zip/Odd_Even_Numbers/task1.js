for (var i=1;i<=100;i+=3) {
  if (i%2===0) {
    console.log(i+"-genap");
  } else {
    console.log(i+"-ganjil");
  }
}
