for (var i = 50; i<=200; i+=5) {
  if (i%3===0) {
    console.log(i+"-faktor 3");
  } else {
    console.log(i+"-tidak bisa dibagi 3");
  }
}
