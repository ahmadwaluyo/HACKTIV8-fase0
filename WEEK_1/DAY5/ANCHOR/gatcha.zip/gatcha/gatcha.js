var tombol = Math.floor(Math.random()*5)+1;
switch (tombol) {
  case 1:
        console.log("coba lagi ya");
        break;
  case 2:
        console.log("selamat anda mendapatkan kupon karcis sebanyak 5");
        break;
  case 3:
        console.log("selamat anda mendapatkan kupon karcis sebanyak 15");
        break;
  case 4:
        console.log("selamat anda mendapatkan kupon karcis sebanyak 50");
        break;
  case 5:
        console.log("WOW kamu menang JACKPOT ! SELAMAT !");
    break;
}
