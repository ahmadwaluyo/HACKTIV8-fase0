var i = 1;
var j = 20;
console.log("LOOPING WHILE PERTAMA");
while (i<=20) {
  console.log(i+"-i love coding");
  i++;
}
console.log("LOOPING WHILE KEDUA");
while (j>=1) {
  console.log(j+"-I will become fullstack developer");
  j--;
}
