
  console.log("LOOPING FOR PERTAMA");
  for (var i = 1; i <=20 ; i++) {
  console.log(i+"-i love coding");
  }
  console.log("LOOPING FOR KEDUA");
  for (var j = 20; j >= 1 ; j--) {
  console.log(j+"-I will become fullstack developer");
  }
i
