var word = 'wow JavaScript is so cool';
var firstWord = word[0]+word[1]+word[2];
var secondWord = word[4]+word[5]+word[6]+word[7]+word[8]+word[9]+word[10]+word[11]+word[12]+word[13];
var thirdWord = word[15]+word[16];
var fourthWord = word[18]+word[19]; // do your own!
var fifthWord = word[21]+word[22]+word[23]+word[24]; // do your own!

console.log('First Word: ' + firstWord);
console.log('Second Word: ' + secondWord);
console.log('Third Word: ' + thirdWord);
console.log('Fourth Word: ' + fourthWord);
console.log('Fifth Word: ' + fifthWord);


// First Word: wow
// Second Word: JavaScript
// Third Word: is
// Fourth Word: so
// Fifth Word: cool
