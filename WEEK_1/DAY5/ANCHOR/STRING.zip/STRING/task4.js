var word4 = 'wow JavaScript is so cool';
var firstWord4 = word4.substring(0, 3);
var secondWord4 = word4.substring(4, 14);
var thirdWord4 = word4.substring(15, 17);
var fourthWord4 = word4.substring(18, 20);
var fifthWord4 = word4.substring(21, 25);

var firstWordLength = firstWord4.length;
var secondWordLength = secondWord4.length;
var thirdWordLength = thirdWord4.length;
var fourthWordLength = fourthWord4.length;
var fifthWordLength = fifthWord4.length;
// create new variables around here

console.log('First Word: ' + firstWord4 + ', with length: ' + firstWordLength);
console.log('Second Word: ' + secondWord4+ ', with length: ' + secondWordLength);
console.log('Third Word: ' + thirdWord4+ ', with length: ' + thirdWordLength);
console.log('Fourth Word: ' + fourthWord4+ ', with length: ' + fourthWordLength);
console.log('Fifth Word: ' + fifthWord4+ ', with length: ' + fifthWordLength);
