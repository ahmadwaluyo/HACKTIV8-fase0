for (var i=1; i <=20; i++) {
  console.log("Masukkan pakaian ke-"+i);
  if (i === 20) {
    console.log("mesin menyala");
  }
}

/*PSEUDO CODE
FOR VAR i equal 1, VAR i lower or equal 20, i and more
DISPLAY "put your cloth in for -"+ VAR i step
IF conditional i equal 20
DISPLAY "machine turning on"
*/
